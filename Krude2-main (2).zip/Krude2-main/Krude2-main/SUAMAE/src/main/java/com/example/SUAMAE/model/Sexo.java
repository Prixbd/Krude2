package com.example.SUAMAE.model;

public enum Sexo {
    MASCULINO,
    FIMININO;
}
